import React from 'react';
import Dashboard from '@/components/Dashboard';

const Index: React.FC = () => {
  return <Dashboard />;
};

export default Index; 